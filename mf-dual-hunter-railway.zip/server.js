/**
 * MyFatoorah Dual Lead Hunter — Railway Edition
 * Mode A: POS Hunter     → physical merchants, ~100K AED/month avg revenue
 * Mode B: Payment Links  → online/service businesses needing checkout
 */

const express = require('express');
const puppeteer = require('puppeteer-extra');
const StealthPlugin = require('puppeteer-extra-plugin-stealth');
const Database = require('better-sqlite3');
const axios = require('axios');
const cheerio = require('cheerio');
const path = require('path');

puppeteer.use(StealthPlugin());

const app = express();
const PORT = process.env.PORT || 3000;

// ─── DATABASE ─────────────────────────────────────────────────────────────────
const db = new Database(path.join(__dirname, 'leads.sqlite'));
db.exec(`
  CREATE TABLE IF NOT EXISTS leads (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    mode         TEXT NOT NULL,         -- 'POS' or 'PAYLINK'
    name         TEXT,
    license      TEXT,
    phone        TEXT  DEFAULT 'Pending',
    email        TEXT  DEFAULT 'Pending',
    website      TEXT  DEFAULT 'Pending',
    address      TEXT  DEFAULT 'Pending',
    review_count INTEGER DEFAULT 0,
    has_website  INTEGER DEFAULT 0,     -- 0/1
    revenue_est  TEXT  DEFAULT 'Calculating',
    fit_score    INTEGER DEFAULT 0,     -- 0-100
    priority     TEXT  DEFAULT 'COLD',  -- HOT / WARM / COLD
    reason       TEXT  DEFAULT '',
    source       TEXT,
    status       TEXT  DEFAULT 'QUEUED',
    created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(name, mode)
  )
`);

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ─── CONFIG ───────────────────────────────────────────────────────────────────
const GROQ_API_KEY = process.env.GROQ_API_KEY || '';
const GROQ_MODEL   = 'llama-3.1-8b-instant';

// POS TARGET — high foot traffic, physical presence, ~100K AED revenue
const POS_CATEGORIES = [
  'Restaurant','Cafe','Coffee Shop','Salon','Barber','Spa',
  'Pharmacy','Clinic','Dental','Supermarket','Grocery',
  'Boutique','Fashion','Jewelry','Electronics Store',
  'Auto Service','Car Wash','Fitness','Gym','Laundry',
  'Bakery','Hotel','Florist','Optical','Toy Store',
];

// PAYMENT LINKS TARGET — online/service, needs checkout infrastructure
const PAYLINK_CATEGORIES = [
  'Online Store','E-commerce','Digital Agency','Freelance',
  'Consultancy','Training','Coaching','Photography',
  'Event Management','Catering','Home Services','Tutoring',
  'Legal Services','Accounting','IT Support','Marketing Agency',
  'Interior Design','Architecture','Real Estate Agency',
  'Travel Agency','Insurance','Healthcare Services',
];

// Known payment gateway indicators — if found on site → lower priority for PAYLINK
const GATEWAY_KEYWORDS = [
  'stripe','payfort','checkout.com','network international','telr',
  'paypal','2checkout','hyperpay','paytabs','adyen','tap payments',
  'myfatoorah', // already a client!
];

const USER_AGENTS = [
  'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1',
  'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
];

const BROWSER_ARGS = [
  '--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage',
  '--disable-accelerated-2d-canvas', '--no-first-run', '--no-zygote',
  '--single-process', '--disable-gpu',
  '--disable-blink-features=AutomationControlled',
];

const PORTAL_BLACKLIST = new Set([
  'services','contact','about','home','search','login','menu','sign in',
  'sign up','start your','find any','business directory','invest in dubai',
  'government','follow us','privacy','terms','cookie','navigation',
]);

// ─── UAE EXTRACTORS ───────────────────────────────────────────────────────────
function extractPhone(text) {
  const patterns = [
    /\+971[-\s]?(?:5[024568]|4|2|3|6|7|9)[-\s]?\d{3}[-\s]?\d{4}/g,
    /\b0(?:5[024568]|4|2|3|6|7|9)[-\s]?\d{3}[-\s]?\d{4}\b/g,
    /\b04[-\s]?\d{3}[-\s]?\d{4}\b/g,
  ];
  for (const p of patterns) {
    const m = text.match(p);
    if (m?.[0]) return m[0].replace(/\s+/g, ' ').trim();
  }
  return '';
}

function extractEmail(text) {
  const m = text.match(/[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/);
  return m ? m[0].toLowerCase() : '';
}

function extractWebsite(text, name = '') {
  const all = [...text.matchAll(/https?:\/\/(?:www\.)?([a-zA-Z0-9\-]+\.[a-zA-Z]{2,}(?:\/[^\s"<>]*)?)/g)];
  if (!all.length) return '';
  const ae = all.filter(m => m[1].endsWith('.ae'));
  if (ae.length) return ae[0][0].split(/["'\s<>]/)[0];
  const hint = name.toLowerCase().replace(/\s+/g, '');
  const named = all.find(m => m[1].toLowerCase().replace(/[-]/g,'').includes(hint.substring(0,5)));
  if (named) return named[0].split(/["'\s<>]/)[0];
  return all[0][0].split(/["'\s<>]/)[0];
}

function extractAddress(text) {
  const kw = ['road','street','building','floor','office','po box','al ','dubai','sharjah','abu dhabi','ajman'];
  for (const line of text.split('\n').map(l => l.trim()).filter(l => l.length > 8 && l.length < 120)) {
    if (kw.some(k => line.toLowerCase().includes(k))) return line;
  }
  return '';
}

function extractReviewCount(text) {
  const m = text.match(/([\d,]+)\s+(?:reviews?|ratings?)/i);
  if (m) return parseInt(m[1].replace(/,/g, ''), 10);
  return 0;
}

// ─── REVENUE ESTIMATE (POS mode) ─────────────────────────────────────────────
function estimateRevenue(reviewCount, category) {
  // Benchmark: Dubai restaurant with 200 reviews = ~150K AED/month
  // Calibrated by business type
  const multipliers = {
    restaurant: 700, cafe: 500, 'coffee shop': 500, pharmacy: 1200,
    clinic: 1500, dental: 1800, supermarket: 2000, grocery: 1000,
    salon: 400, barber: 300, spa: 600, boutique: 800, fashion: 700,
    jewelry: 2000, electronics: 1500, gym: 500, fitness: 450,
    hotel: 3000, bakery: 400, 'car wash': 350, 'auto service': 900,
  };
  const cat = category.toLowerCase();
  let mult = 600; // default AED per review
  for (const [k, v] of Object.entries(multipliers)) {
    if (cat.includes(k)) { mult = v; break; }
  }
  const monthly = reviewCount * mult;
  if (monthly < 50000)  return { range: '< 50K AED/mo',  target: false, num: monthly };
  if (monthly < 100000) return { range: '50–100K AED/mo', target: true,  num: monthly };
  if (monthly < 300000) return { range: '100–300K AED/mo', target: true, num: monthly };
  if (monthly < 1000000) return { range: '300K–1M AED/mo', target: true, num: monthly };
  return { range: '> 1M AED/mo', target: true, num: monthly };
}

// ─── SCORING LOGIC ────────────────────────────────────────────────────────────
function scorePOS(lead) {
  // POS target: physical, good revenue, no digital payment = need a terminal
  let score = 0;
  const reasons = [];

  const rev = estimateRevenue(lead.review_count, lead.source || '');
  if (rev.target) { score += 35; reasons.push(`Rev ~${rev.range}`); }
  if (lead.review_count >= 100) { score += 25; reasons.push(`${lead.review_count} reviews`); }
  else if (lead.review_count >= 40) { score += 15; reasons.push(`${lead.review_count} reviews`); }
  if (!lead.has_website || lead.website === 'Not Found') { score += 20; reasons.push('No website detected'); }
  if (lead.phone && lead.phone !== 'Not Found') { score += 10; reasons.push('Phone verified'); }
  if (lead.address && lead.address !== 'Not Found') { score += 10; reasons.push('Address found'); }

  const priority = score >= 70 ? 'HOT' : score >= 40 ? 'WARM' : 'COLD';
  return { score, priority, reason: reasons.join(' · '), revenue_est: rev.range };
}

function scorePAYLINK(lead) {
  // PayLink target: online presence, sells digitally, NO existing gateway
  let score = 0;
  const reasons = [];

  if (lead.has_website) { score += 30; reasons.push('Has website'); }
  if (lead.email && lead.email !== 'Not Found') { score += 15; reasons.push('Email reachable'); }

  // Check if they already have a gateway (lower score)
  const allText = [lead.website, lead.address].join(' ').toLowerCase();
  const hasGateway = GATEWAY_KEYWORDS.some(kw => allText.includes(kw));
  if (!hasGateway) { score += 35; reasons.push('No gateway detected'); }
  else { score -= 20; reasons.push('Existing gateway found'); }

  if (lead.review_count >= 20) { score += 10; reasons.push(`${lead.review_count} reviews`); }
  if (lead.phone && lead.phone !== 'Not Found') { score += 10; reasons.push('Phone verified'); }

  const priority = score >= 70 ? 'HOT' : score >= 40 ? 'WARM' : 'COLD';
  return { score: Math.max(0, score), priority, reason: reasons.join(' · '), revenue_est: 'N/A' };
}

// ─── GROQ AI (free, fast — works in Railway cloud) ────────────────────────────
async function aiExtract(rawText, businessName) {
  if (!GROQ_API_KEY) return null;
  try {
    const res = await axios.post(
      'https://api.groq.com/openai/v1/chat/completions',
      {
        model: GROQ_MODEL,
        messages: [{
          role: 'user',
          content: `Extract contact info for "${businessName}" from this web text.
Return ONLY JSON: {"phone":"","email":"","website":"","address":"","review_count":0,"has_website":0}
has_website = 1 if they have a real website (not just facebook/instagram).
review_count = number of Google reviews found.
Empty string if not found. No explanation.
Text: ${rawText.substring(0, 1800)}`,
        }],
        temperature: 0,
        max_tokens: 250,
      },
      {
        headers: { Authorization: `Bearer ${GROQ_API_KEY}`, 'Content-Type': 'application/json' },
        timeout: 8000,
      }
    );
    const content = res.data.choices[0].message.content;
    const m = content.match(/\{[\s\S]*?\}/);
    return m ? JSON.parse(m[0]) : null;
  } catch { return null; }
}

// ─── SCRAPE PORTAL ────────────────────────────────────────────────────────────
async function scrapeDubaiPortal(keyword) {
  const browser = await puppeteer.launch({
    headless: 'new', args: BROWSER_ARGS,
    executablePath: process.env.PUPPETEER_EXECUTABLE_PATH || undefined,
  });
  let results = [];
  try {
    const page = await browser.newPage();
    await page.setUserAgent(USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)]);
    const url = `https://www.investindubai.gov.ae/en/dubai-business-directory-search?tagName=Business+name&tagTitle=${encodeURIComponent(keyword)}`;
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 25000 });
    await page.waitForTimeout(4000);

    results = await page.evaluate((bl) => {
      const selectors = [
        '[data-testid="directory-card"]','.directory-listing-card',
        '.sc-card','[class*="CardWrapper"]','[class*="card-wrapper"]',
        '[class*="directory-card"]','.result-item','article',
      ];
      let cards = [];
      for (const sel of selectors) {
        const found = document.querySelectorAll(sel);
        if (found.length > 0) { cards = Array.from(found); break; }
      }
      return cards.map(el => {
        const text = el.innerText || '';
        const name = (text.split('\n')[0] || '').trim();
        const licM = text.match(/[A-Z]{1,4}[-\s]?\d{4,}/);
        return { name, license: licM ? licM[0] : 'N/A' };
      }).filter(r => {
        if (!r.name || r.name.length < 3 || r.name.length > 100) return false;
        const lower = r.name.toLowerCase();
        return !bl.some(b => lower.includes(b));
      });
    }, [...PORTAL_BLACKLIST]);

  } catch (e) {
    console.error('[PORTAL]', e.message);
  } finally {
    await browser.close();
  }

  if (results.length === 0) {
    console.log('[PORTAL] Empty → DuckDuckGo fallback');
    results = await searchDDG(keyword + ' company Dubai UAE');
  }
  return results;
}

// ─── DUCKDUCKGO FALLBACK ──────────────────────────────────────────────────────
async function searchDDG(query) {
  try {
    const { data } = await axios.get(
      `https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}`,
      { headers: { 'User-Agent': USER_AGENTS[0] }, timeout: 10000 }
    );
    const $ = cheerio.load(data);
    const results = [];
    $('.result__title').each((i, el) => {
      if (i >= 12) return false;
      const name = $(el).text().trim();
      if (name && name.length > 3 && name.length < 80 && !name.toLowerCase().includes('reddit'))
        results.push({ name, license: 'WEB' });
    });
    return results;
  } catch { return []; }
}

// ─── ENRICH LEAD ──────────────────────────────────────────────────────────────
async function enrichLead(name) {
  const browser = await puppeteer.launch({
    headless: 'new', args: BROWSER_ARGS,
    executablePath: process.env.PUPPETEER_EXECUTABLE_PATH || undefined,
  });
  let result = { phone: '', email: '', website: '', address: '', review_count: 0, has_website: 0 };

  try {
    const page = await browser.newPage();
    await page.setUserAgent(USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)]);

    // Google Search
    await page.goto(
      `https://www.google.com/search?q=${encodeURIComponent('"' + name + '" Dubai contact')}`,
      { waitUntil: 'domcontentloaded', timeout: 15000 }
    );
    await page.waitForTimeout(2000);
    const searchText = await page.evaluate(() => document.body.innerText);

    // Try AI first, then regex
    const ai = await aiExtract(searchText, name);
    if (ai) {
      result.phone        = ai.phone        || extractPhone(searchText)   || '';
      result.email        = ai.email        || extractEmail(searchText)   || '';
      result.website      = ai.website      || extractWebsite(searchText, name) || '';
      result.address      = ai.address      || extractAddress(searchText) || '';
      result.review_count = ai.review_count || extractReviewCount(searchText)  || 0;
      result.has_website  = ai.has_website  || (result.website ? 1 : 0);
    } else {
      result.phone        = extractPhone(searchText)        || '';
      result.email        = extractEmail(searchText)        || '';
      result.website      = extractWebsite(searchText, name) || '';
      result.address      = extractAddress(searchText)      || '';
      result.review_count = extractReviewCount(searchText)  || 0;
      result.has_website  = result.website ? 1 : 0;
    }

    // Supplement with Google Maps if phone still missing
    if (!result.phone || !result.review_count) {
      await page.goto(
        `https://www.google.com/maps/search/${encodeURIComponent(name + ' Dubai')}`,
        { waitUntil: 'domcontentloaded', timeout: 12000 }
      );
      await page.waitForTimeout(2500);
      const mapsText = await page.evaluate(() => document.body.innerText);
      result.phone        = result.phone        || extractPhone(mapsText)        || '';
      result.email        = result.email        || extractEmail(mapsText)        || '';
      result.address      = result.address      || extractAddress(mapsText)      || '';
      result.review_count = result.review_count || extractReviewCount(mapsText)  || 0;
    }

  } catch (e) {
    console.error(`[ENRICH] ${name}:`, e.message);
  } finally {
    await browser.close();
  }

  // Normalise empty → 'Not Found'
  ['phone','email','website','address'].forEach(k => {
    if (!result[k]) result[k] = 'Not Found';
  });
  return result;
}

// ─── ENRICHMENT QUEUE ─────────────────────────────────────────────────────────
const queues = { POS: [], PAYLINK: [] };
const processing = { POS: false, PAYLINK: false };

async function processQueue(mode) {
  if (processing[mode] || queues[mode].length === 0) return;
  processing[mode] = true;

  const item = queues[mode].shift();
  console.log(`[${mode}] Enriching: ${item.name}`);

  try {
    const contact = await enrichLead(item.name);
    const scored  = mode === 'POS'
      ? scorePOS({ ...contact, source: item.source, review_count: contact.review_count })
      : scorePAYLINK({ ...contact, source: item.source });

    db.prepare(`
      UPDATE leads SET
        phone=?, email=?, website=?, address=?,
        review_count=?, has_website=?,
        revenue_est=?, fit_score=?, priority=?, reason=?,
        status='COMPLETE'
      WHERE id=?
    `).run(
      contact.phone, contact.email, contact.website, contact.address,
      contact.review_count, contact.has_website,
      scored.revenue_est, scored.score, scored.priority, scored.reason,
      item.id
    );
    console.log(`[${mode}] ✓ ${item.name} → ${scored.priority} | ${scored.reason}`);
  } catch (e) {
    db.prepare(`UPDATE leads SET status='ERROR' WHERE id=?`).run(item.id);
    console.error(`[${mode}] ERROR:`, e.message);
  }

  processing[mode] = false;
  setTimeout(() => processQueue(mode), 3500);
}

// ─── ROUTES ───────────────────────────────────────────────────────────────────

// POST /api/search  body: { mode: 'POS'|'PAYLINK', keyword: '' }
app.post('/api/search', async (req, res) => {
  const mode = (req.body.mode || 'POS').toUpperCase();
  if (!['POS','PAYLINK'].includes(mode)) return res.status(400).json({ error: 'Invalid mode' });

  const pool = mode === 'POS' ? POS_CATEGORIES : PAYLINK_CATEGORIES;
  let keyword = (req.body.keyword || '').trim();
  if (!keyword) keyword = pool[Math.floor(Math.random() * pool.length)];

  console.log(`[${mode}] Hunt: "${keyword}"`);
  res.json({ status: 'ok', mode, keyword, message: `Scanning for "${keyword}" [${mode} mode]...` });

  try {
    const businesses = await scrapeDubaiPortal(keyword);
    console.log(`[${mode}] Found ${businesses.length} for "${keyword}"`);

    const ins = db.prepare(`
      INSERT OR IGNORE INTO leads (mode, name, license, source, status)
      VALUES (?,?,?,?,'QUEUED')
    `);
    const get = db.prepare(`SELECT id, name FROM leads WHERE name=? AND mode=?`);

    for (const b of businesses) {
      const r = ins.run(mode, b.name, b.license, keyword);
      if (r.changes > 0) {
        const row = get.get(b.name, mode);
        if (row) queues[mode].push({ ...row, source: keyword });
      }
    }
    processQueue(mode);
  } catch (e) {
    console.error('[SEARCH]', e.message);
  }
});

// GET /api/leads?mode=POS|PAYLINK
app.get('/api/leads', (req, res) => {
  const mode = (req.query.mode || 'POS').toUpperCase();
  const leads = db.prepare(`
    SELECT * FROM leads
    WHERE mode=?
    ORDER BY
      CASE priority WHEN 'HOT' THEN 1 WHEN 'WARM' THEN 2 ELSE 3 END,
      fit_score DESC, id DESC
    LIMIT 250
  `).all(mode);
  res.json(leads);
});

// GET /api/stats?mode=POS|PAYLINK
app.get('/api/stats', (req, res) => {
  const mode = (req.query.mode || 'POS').toUpperCase();
  const s = db.prepare(`
    SELECT
      COUNT(*) as total,
      SUM(CASE WHEN status='COMPLETE' THEN 1 ELSE 0 END) as complete,
      SUM(CASE WHEN priority='HOT' THEN 1 ELSE 0 END) as hot,
      SUM(CASE WHEN priority='WARM' THEN 1 ELSE 0 END) as warm
    FROM leads WHERE mode=?
  `).get(mode);
  res.json({ ...s, queued: queues[mode].length });
});

// GET /api/export?mode=POS|PAYLINK
app.get('/api/export', (req, res) => {
  const mode = (req.query.mode || 'POS').toUpperCase();
  const leads = db.prepare(`SELECT * FROM leads WHERE mode=? AND status='COMPLETE' ORDER BY fit_score DESC`).all(mode);
  const headers = ['name','license','phone','email','website','address','review_count','revenue_est','fit_score','priority','reason','source','created_at'];
  const rows = leads.map(l => headers.map(h => `"${(l[h]||'').toString().replace(/"/g,'""')}"`).join(','));
  res.setHeader('Content-Type','text/csv');
  res.setHeader('Content-Disposition',`attachment; filename="mf_${mode.toLowerCase()}_leads.csv"`);
  res.send([headers.join(','), ...rows].join('\n'));
});

// DELETE /api/leads?mode=POS|PAYLINK|ALL
app.delete('/api/leads', (req, res) => {
  const mode = (req.query.mode || '').toUpperCase();
  if (mode === 'ALL') {
    db.prepare('DELETE FROM leads').run();
    queues.POS = []; queues.PAYLINK = [];
  } else {
    db.prepare('DELETE FROM leads WHERE mode=?').run(mode);
    queues[mode] = [];
  }
  res.json({ status: 'ok' });
});

app.get('/health', (req, res) => res.json({ status:'online', qPOS: queues.POS.length, qPAYLINK: queues.PAYLINK.length }));
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

app.listen(PORT, '0.0.0.0', () => {
  console.log(`[MF DUAL HUNTER] Port ${PORT}`);
  console.log(`[MF DUAL HUNTER] Groq AI: ${GROQ_API_KEY ? 'ENABLED' : 'regex fallback'}`);
});
